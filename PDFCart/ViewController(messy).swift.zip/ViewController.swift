//
//  ViewController.swift
//  PDFCart
//
//  Created by Admin1 on 26/06/20.
//  Copyright © 2020 Admin1. All rights reserved.
//

import UIKit
import PDFKit
import Toast_Swift
import FTPopOverMenu_Swift

struct Product {
    var locations : CGRect = CGRect.zero
    var name : String = "Item 1"
    var price : String = "10$"
}

let pdfTotalHeight = 1557
let pdfTotalWidth = 1389

class ViewController: UIViewController,PDFViewDelegate,UIGestureRecognizerDelegate {
    
    //MARK: OBJECTS DECLARATION
    @IBOutlet weak var pdfView: PDFView!
    
    private var shouldUpdatePDFScrollPosition = true
    var currentlySelectedAnnotation: PDFAnnotation?

    var gesturePDFAnnotationTap = UITapGestureRecognizer()

    var arrayProduct : [Product] = []
    
    var isAnnotationHit = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.arrayProduct.append(Product(locations: CGRect(x: 50.0, y: 20.0,width:50 ,height:80), name: "Milk", price: "15"))
        self.arrayProduct.append(Product(locations: CGRect(x: 384, y: 354,width:50 ,height:80), name: "Water", price: "20"))
        self.arrayProduct.append(Product(locations: CGRect(x: 1054, y: 358,width:50 ,height:80), name: "Cookies", price: "50"))
//        self.arrayProduct.append(Product(locations: (x: 75.0, y: 65.0), name: "Dairy Milk", price: "150"))
//        self.arrayProduct.append(Product(locations: (x: 350.0, y: 50.0), name: "Watermalon", price: "75"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Cupcake", price: "15"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Chezee", price: "25"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Grapes", price: "35"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Onions", price: "70"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Garlic", price: "56"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Patato", price: "56"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Chips", price: "45"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Ghee", price: "566"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Noodles", price: "56"))
//        self.arrayProduct.append(Product(locations: <#T##(x: Float, y: Float)#>, name: "Wine", price: "700"))


        self.loadPDF()
        
        gesturePDFAnnotationTap = UITapGestureRecognizer(target: self, action: #selector(self.singleHandleTap(_:)))
        gesturePDFAnnotationTap.numberOfTapsRequired = 1
        gesturePDFAnnotationTap.delegate = self
        self.pdfView.addGestureRecognizer(gesturePDFAnnotationTap)
        
        // create a new style
        var style = ToastStyle()

        
        // Toast Setup
        
        // this is just one of many style options
        style.messageColor = .black
        style.backgroundColor = .systemYellow
        ToastManager.shared.style = style

        // Popup Setup
        let configuration = FTConfiguration.shared
        configuration.menuRowHeight = 45
        configuration.menuWidth = 100
        //configuration.textColor = ...
        

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    // This code is required to fix PDFView Scroll Position when NOT using pdfView.usePageViewController(true)
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        shouldUpdatePDFScrollPosition = false
        
        /* notification */
        self.addPDFNotificationObservers()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.removePDFNotificationObservers()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pdfView.autoScales = true
    }
    // This code is required to fix PDFView Scroll Position when NOT using pdfView.usePageViewController(true)
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
//        if shouldUpdatePDFScrollPosition {
//            fixPDFViewScrollPosition()
//        }
    }
    // This code is required to fix PDFView Scroll Position when NOT using pdfView.usePageViewController(true)
    private func fixPDFViewScrollPosition() {
        if let page = pdfView.document?.page(at: 0) {
            pdfView.go(to: PDFDestination(page: page, at: CGPoint(x: 0, y: page.bounds(for: pdfView.displayBox).size.height)))
        }
    }

    //MARK: PDF SETUP / LOADING PDF
    func loadPDF() {
        // Setup PDF View
        pdfView.displayDirection = .vertical
        pdfView.pageBreakMargins = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        pdfView.delegate = self
        pdfView.minScaleFactor = pdfView.scaleFactorForSizeToFit
        
        self.reloadPDF()
    }

    func reloadPDF() {
                
        // Load PDF File
        if let filePath = self.pdfView.filePath(forKey: "Item2") {
            
            if let document = PDFDocument(url: filePath) {
                pdfView.document = document
                
            }else{
                guard let path = Bundle.main.url(forResource: "Item2", withExtension: "pdf") else {
                    print("file not found")
                    return
                }
                pdfView.document = PDFDocument(url: path)
            }
        }else{
            guard let path = Bundle.main.url(forResource: "Item2", withExtension: "pdf") else {
                print("file not found")
                return
            }
            pdfView.document = PDFDocument(url: path)
        }
        pdfView.displayMode = .singlePageContinuous
        pdfView.sizeToFit()
        pdfView.autoScales = true
        
    }

    @objc func singleHandleTap(_ gestureRecognizer: UITapGestureRecognizer) {
        if isAnnotationHit{
            isAnnotationHit = false
            return
        }
        
        guard gestureRecognizer.view != nil else { return }
        
        if gestureRecognizer.state == .ended {
            let touchLocation = gestureRecognizer.location(in: self.pdfView)
            guard let page = self.pdfView.page(for: touchLocation, nearest: true)
                else {
                    return
            }
            print("## touchLocation : \(touchLocation)")
            
            let touchLocationConverter = self.pdfView.convert(touchLocation, to: page)
            print("## touchLocation converter: \(touchLocationConverter)")
    
            let objectWidth : CGFloat = 150.0
            let objectHeight : CGFloat = 150.0
            
            let rrrEct = CGRect(x: touchLocation.x - (objectWidth/2), y: touchLocation.y - (objectHeight/2), width: objectWidth, height: objectHeight).scaled(by: pdfView.scaleFactor)
            let conver = self.pdfView.convert(rrrEct, to: page)
         
             
            print("Rect Rounded Converted : \(conver)")
        
                        
            let pageBounds = page.bounds(for: .cropBox)
            let newAnnotation = PDFAnnotation(bounds: pageBounds, forType: .circle,withProperties:nil)
            newAnnotation.setRect(conver, forAnnotationKey: .rect)
            newAnnotation.color = UIColor.systemYellow.withAlphaComponent(0.8)
            
            let border = PDFBorder()
            border.lineWidth = 20
            border.style = .solid
            newAnnotation.border = border
            
            UIView.animate(withDuration: 0.1,
                       delay: 0.1,
                       options: UIView.AnimationOptions.curveEaseIn,
                       animations: { () -> Void in
                        page.addAnnotation(newAnnotation)
                        self.view.layoutIfNeeded()
            }, completion: { (finished) -> Void in
                self.showToast(message: "Item added to cart.")
            })

        }
    }
    
    
    func showToast(message: String) {
        // toast with a specific duration and position
        self.view.makeToast(message, duration: 1.0, position: .bottom)
    }
    
    @IBAction func btnItemsClicked(sender: UIButton) {
//        pdfView.scaleFactorForSizeToFit = 10
        
        FTPopOverMenu.showForSender(sender: sender,
                                    with: ["All","Logitech","D-Link"],
                                    done: { (selectedIndex) -> () in
                              
                                        print(selectedIndex)
                                        if selectedIndex == 0{
                                            UIView.animate(withDuration: 0.5) {
                                                let documents = self.pdfView.document
                                                if let page = documents?.page(at: 0) {
                                                    self.pdfView.scaleFactor = self.pdfView.scaleFactorForSizeToFit
//                                                    let rect = CGRect(x: 20, y: 160, width: 0, height: 0)
//                                                    self.pdfView.go(to: rect, on: page)
                                                }
                                            }
                                        }
                                        if selectedIndex == 1{
                                            UIView.animate(withDuration: 0.5) {
                                                let documents = self.pdfView.document
                                                if let page = documents?.page(at: 0) {
                                                    self.pdfView.scaleFactor = self.pdfView.scaleFactorForSizeToFit * 5
                                                    let rect = CGRect(x: 20, y: 160, width: 800, height: 500)
                                                    self.pdfView.go(to: rect, on: page)
                                                }
                                            }
                                        }
                                        if selectedIndex == 2{
                                            UIView.animate(withDuration: 0.5) {
                                                let documents = self.pdfView.document
                                                if let page = documents?.page(at: 0) {
                                                    self.pdfView.scaleFactor = self.pdfView.scaleFactorForSizeToFit * 5
                                                    let rect = CGRect(x: 780, y: 160, width: 800, height: 500)
                                                    self.pdfView.go(to: rect, on: page)
                                                }
                                            }
                                        }
                                        if selectedIndex == 2{
                                        }
        }) {
        }
    }

}

extension ViewController{
    //MARK: NOTIFICATION METHOD LISTED..
    func addPDFNotificationObservers(){
        NotificationCenter.default.addObserver (self, selector: #selector(handlePageChange), name: Notification.Name.PDFViewPageChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(handleAnnotationHit), name: Notification.Name.PDFViewAnnotationHit, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewDocumentChanged), name: Notification.Name.PDFViewDocumentChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewChangedHistory), name: Notification.Name.PDFViewChangedHistory, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewScaleChanged), name: Notification.Name.PDFViewScaleChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewCopyPermission), name: Notification.Name.PDFViewCopyPermission, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewPrintPermission), name: Notification.Name.PDFViewPrintPermission, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewAnnotationWillHit), name: Notification.Name.PDFViewAnnotationWillHit, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewDisplayModeChanged), name: Notification.Name.PDFViewDisplayModeChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewDisplayBoxChanged), name: Notification.Name.PDFViewDisplayBoxChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewVisiblePagesChanged), name: Notification.Name.PDFViewVisiblePagesChanged, object: nil)
        NotificationCenter.default.addObserver (self, selector: #selector(pdfViewSelectionChanged), name: Notification.Name.PDFViewSelectionChanged, object: nil)
    }
    func removePDFNotificationObservers(){
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewPageChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewAnnotationHit, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewDocumentChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewChangedHistory, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewScaleChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewCopyPermission, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewPrintPermission, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewAnnotationWillHit, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewDisplayModeChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewDisplayBoxChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewVisiblePagesChanged, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.PDFViewSelectionChanged, object: nil)
    }
    @objc func handlePageChange() {
        print("Notification : handlePageChange")
    }
    @objc func pdfViewDocumentChanged() {
        print("Notification : pdfViewDocumentChanged")
    }
    @objc func pdfViewChangedHistory() {
        print("Notification : pdfViewChangedHistory")
    }
    @objc func pdfViewScaleChanged() {
        print("Notification : pdfViewScaleChanged")
    }
    @objc func pdfViewCopyPermission() {
        print("Notification : pdfViewCopyPermission")
    }
    @objc func pdfViewPrintPermission() {
        print("Notification : pdfViewPrintPermission")
    }
    @objc func pdfViewDisplayModeChanged() {
        print("Notification : pdfViewDisplayModeChanged")
    }
    @objc func pdfViewDisplayBoxChanged() {
        print("Notification : pdfViewDisplayBoxChanged")
    }
    @objc func pdfViewVisiblePagesChanged() {
        print("Notification : pdfViewVisiblePagesChanged")
    }
    @objc func handleAnnotationHit(notification : NSNotification) {
        print("handleAnnotationHit")
        isAnnotationHit = true
        let annotation = notification.userInfo!["PDFAnnotationHit"] as! PDFAnnotation
        self.pdfView.currentPage?.removeAnnotation(annotation)
        self.pdfView.annotationsChanged(on: self.pdfView.currentPage!)
        
        showToast(message: "Item removed from cart.")
    }
    @objc func pdfViewAnnotationWillHit(notification : NSNotification) {
        print("Notification : pdfViewAnnotationWillHit")
    }
    @objc func pdfViewSelectionChanged(notification : NSNotification.Name) {
        print("Notification : pdfViewSelectionChanged")
    }
    
}

extension PDFView{
    override open func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
    
    func filePath(forKey key: String) -> URL? {
        let fileManager = FileManager.default
        guard let documentURL = fileManager.urls(for: .documentDirectory,
                                                 in: FileManager.SearchPathDomainMask.userDomainMask).first else { return nil }
        return documentURL.appendingPathComponent(key + ".pdf")
    }
    
    func store(forKey key: String) {
        if let filePath = filePath(forKey: key) {
            print("File Stored At : \(filePath)")
            self.document?.write(to: filePath)
        }
    }
    
}

extension CGRect{
    func scaled(by scaleFactor: CGFloat) -> CGRect {
        let horizontalInsets = (self.width - (self.width * scaleFactor)) / 2.0
        let verticalInsets = (self.height - (self.height * scaleFactor)) / 2.0
        
        let edgeInsets = UIEdgeInsets(top: verticalInsets, left: horizontalInsets, bottom: verticalInsets, right: horizontalInsets)
        
        let leftOffset = min(self.origin.x + horizontalInsets, 0)
        let upOffset = min(self.origin.y + verticalInsets, 0)

        return self.inset(by: edgeInsets).offsetBy(dx: leftOffset, dy: upOffset)
    }
}
